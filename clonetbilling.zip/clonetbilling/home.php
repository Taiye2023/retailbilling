<?php include 'db_connect.php' ?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Category', 'Sold Per Day'],
          ['Chinese',     11],
          ['Mexican',      2],
          ['Pizza',  2],
          ['Japanese', 2],
          ['Thai',    7]
        ]);

        var options = {
          title: 'Recent Sale'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
<style>
   span.float-right.summary_icon {
    font-size: 3rem;
    position: absolute;
    right: 1rem;
    top: 0;
}
.imgs{
		margin: .5em;
		max-width: calc(100%);
		max-height: calc(100%);
	}
	.imgs img{
		max-width: calc(100%);
		max-height: calc(100%);
		cursor: pointer;
	}
	#imagesCarousel,#imagesCarousel .carousel-inner,#imagesCarousel .carousel-item{
		height: 60vh !important;background: black;
	}
	#imagesCarousel .carousel-item.active{
		display: flex !important;
	}
	#imagesCarousel .carousel-item-next{
		display: flex !important;
	}
	#imagesCarousel .carousel-item img{
		margin: auto;
	}
	#imagesCarousel img{
		width: auto!important;
		height: auto!important;
		max-height: calc(100%)!important;
		max-width: calc(100%)!important;
	}
</style>

<div class="containe-fluid">
	<div class="row mt-3 ml-3 mr-3 dashcard">
        <!-- <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <?php echo "Welcome back". $_SESSION['login_name']."!"  ?>
                    <hr>
                </div>
            </div>      			
        </div> -->

        
        
            <!-- Table Panel -->
            <div class="col-md-12 mb-5">
                <div class="card">
                    <div class="card-header">
                        <b>List of Orders </b>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Invoice</th>
                                    <th>Order Number</th>
									<th>Sold By</th>
                                    <th>NGR Amount</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $i = 1;
                                $order = $conn->query("SELECT * FROM orders order by unix_timestamp(date_created) desc ");
                                while($row=$order->fetch_assoc()):
                                ?>
                                <tr>
                                    <td class="text-center"><?php echo $i++ ?></td>
                                    <td>
                                        <p> <?php echo date("M d,Y",strtotime($row['date_created'])) ?></p>
                                    </td>
                                    <td>
                                        <p> <?php echo $row['amount_tendered'] > 0 ? $row['ref_no'] : 'N/A' ?></p>
                                    </td>
                                    <td>
                                        <p><?php echo $row['order_number'] ?></p>
                                    </td>
									<td>
                                        <p><?php echo $_SESSION['login_name'].""  ?></p>
                                    </td>
                                    <td>
                                        <p class="text-right">NGR  <?php echo number_format($row['total_amount'],2) ?></p>
                                    </td>
                                    <td class="text-center">
                                          <?php if($row['amount_tendered'] > 0): ?>
                                            <span class="badge badge-success">Paid</span>
                                        <?php else: ?>
                                            <span class="badge badge-primary">Unpaid</span>
                                        <?php endif; ?>
                                    </td>
                                   
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>					
                </div>
				<br>
				<div align="center">
					<p style="color: blue; font-size: 14px;">   CLONET BILLING SOLUTIONS.&copy; 2024 All rights reserved | Design by :<b> </b>VANTAGE POINT +234 (0) 906 6042 380</p>
					</div>
            </div>
			
			
				
				
            <!-- Table Panel -->
    </div>
</div>

 
<script>
	$('#manage-records').submit(function(e){
        e.preventDefault()
        start_load()
        $.ajax({
            url:'ajax.php?action=save_track',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            success:function(resp){
                resp=JSON.parse(resp)
                if(resp.status==1){
                    alert_toast("Data successfully saved",'success')
                    setTimeout(function(){
                        location.reload()
                    },800)

                }
                
            }
        })
    })
    $('#tracking_id').on('keypress',function(e){
        if(e.which == 13){
            get_person()
        }
    })
    $('#check').on('click',function(e){
            get_person()
    })
    function get_person(){
            start_load()
        $.ajax({
                url:'ajax.php?action=get_pdetails',
                method:"POST",
                data:{tracking_id : $('#tracking_id').val()},
                success:function(resp){
                    if(resp){
                        resp = JSON.parse(resp)
                        if(resp.status == 1){
                            $('#name').html(resp.name)
                            $('#address').html(resp.address)
                            $('[name="person_id"]').val(resp.id)
                            $('#details').show()
                            end_load()

                        }else if(resp.status == 2){
                            alert_toast("Unknow tracking id.",'danger');
                            end_load();
                        }
                    }
                }
            })
    }
</script>